//
//  XFPageControl.m
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import "XFPageControl.h"

@implementation XFPageControl

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        _pageControll = [[UILabel alloc]initWithFrame:CGRectMake(5, 3, self.frame.size.width - 10, self.frame.size.height - 6)];
        _pageControll.backgroundColor = [UIColor clearColor];
        _pageControll.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_pageControll];
    }
    return self;
}

@end
