//
//  XFPhotoPickerCell.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/1.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

@interface XFPhotoPickerCell : UICollectionViewCell

@property (strong, nonatomic) UIImageView *photo;

@property (strong, nonatomic) UIButton *selectBtn;

-(void)loadPhotoData:(PHAsset *)assetItem;

-(void)selectBtnStage:(NSMutableArray *)selectArray existence:(PHAsset *)assetItem;

@end
