//
//  XFPhotoPickerViewController.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/1.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

@interface XFPhotoPickerViewController : UIViewController

@property (strong, nonatomic) void(^PhotoResult)(id responseObject);

@property (assign, nonatomic) NSInteger selectNum;

@property (assign, nonatomic) BOOL isAlubSeclect;

@property (strong, nonatomic) PHFetchResult *fetch;

@property (assign, nonatomic) XFImageType imageType;

@end
