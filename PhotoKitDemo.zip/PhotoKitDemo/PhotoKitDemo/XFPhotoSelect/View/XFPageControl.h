//
//  XFPageControl.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFPageControl : UIView

@property (assign, nonatomic) NSInteger currentPage;

@property (strong, nonatomic) UILabel *pageControll;

@end
