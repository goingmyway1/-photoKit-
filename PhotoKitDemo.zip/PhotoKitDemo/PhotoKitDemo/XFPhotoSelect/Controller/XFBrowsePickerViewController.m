//
//  XFBrowsePickerViewController.m
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import "XFBrowsePickerViewController.h"
#import "XFBrowserPickerCell.h"
#import "XFBrowerAnimate.h"
#import "XFPageControl.h"
@interface XFBrowsePickerViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UINavigationControllerDelegate,UIViewControllerTransitioningDelegate>

@property (nonatomic, strong) UICollectionView *picBrowse;
@property (nonatomic, strong) UICollectionViewFlowLayout *flowLayout;

@property (nonatomic, strong) NSMutableArray *photoDataArray;
@property (nonatomic, strong) XFBrowerAnimate *animate;
@property (nonatomic, strong) XFPageControl *pageControl;

//照片的总数
@property (nonatomic, assign) NSInteger numberOfItems;


@end

@implementation XFBrowsePickerViewController

-(NSMutableArray *)photoDataArray{
    if (!_photoDataArray) {
        _photoDataArray = [NSMutableArray array];
    }
    return _photoDataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupCollectionViewUI];
    
    [self setPageControlUI];
    
    [self loadPhotoData];
    
    if ([self.delegate respondsToSelector:@selector(xfbrowserPickerPhotoContent:)]) {
        [self.photoDataArray addObjectsFromArray:[self.delegate xfbrowserPickerPhotoContent:self]];
    }

}
-(void)setupCollectionViewUI
{
    /*
     *   创建 UICollectionView
     */
    self.view.backgroundColor = [UIColor blackColor];
    
    _flowLayout = [[UICollectionViewFlowLayout alloc] init];
    _flowLayout.itemSize = (CGSize){self.view.frame.size.width,self.view.frame.size.height - 64};
    _flowLayout.minimumLineSpacing = 0;
    _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    _picBrowse = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) collectionViewLayout:_flowLayout];
    _picBrowse.backgroundColor = [UIColor clearColor];
    _picBrowse.pagingEnabled = YES;
    _picBrowse.scrollEnabled = YES;
    _picBrowse.showsHorizontalScrollIndicator = NO;
    _picBrowse.showsVerticalScrollIndicator = NO;
    [_picBrowse registerClass:[XFBrowserPickerCell class] forCellWithReuseIdentifier:@"Cell"];
    _picBrowse.dataSource = self;
    _picBrowse.delegate = self;
    
    if (self.indexPath != nil) {
        [_picBrowse scrollToItemAtIndexPath:self.indexPath atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    }
    
    [self.view addSubview:_picBrowse];
}

-(void)setPageControlUI
{
    /*
     *   创建底部PageControl（自定义）
     */
    _pageControl = [[XFPageControl alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height - 84, self.view.frame.size.width, 30)];
    _pageControl.currentPage = 0;
    _pageControl.backgroundColor = [UIColor clearColor];
    _pageControl.pageControll.textColor = [UIColor whiteColor];
    [self.view addSubview:_pageControl];
    
    //照片总数通过delegate获取
    _numberOfItems = [self.delegate xfbrowserPickerPhotoNum:self];
    
    //判断是否需要滚动到指定图片
    if (self.indexPath != nil) {
        _pageControl.pageControll.text = [NSString stringWithFormat:@"%ld / %ld",(long)self.indexPath.row + 1,(long)_numberOfItems];
    }else{
        _pageControl.pageControll.text = [NSString stringWithFormat:@"%d / %ld",1,(long)_numberOfItems];
    }
    
}
-(void)loadPhotoData
{
    if ([self.delegate respondsToSelector:@selector(xfbrowserPickerPhotoContent:)]) {
        [self.photoDataArray addObjectsFromArray:[self.delegate xfbrowserPickerPhotoContent:self]];
    }
}
/*
 *   更新数据刷新方法
 */

-(void)reloadData
{
    
    [_picBrowse reloadData];
    //照片总数通过delegate获取
    if ([self.delegate respondsToSelector:@selector(xfbrowserPickerPhotoNum:)]) {
        _numberOfItems = [self.delegate xfbrowserPickerPhotoNum:self];
    }
    
    //判断是否需要滚动到指定图片
    if (self.indexPath != nil) {
        _pageControl.pageControll.text = [NSString stringWithFormat:@"%ld / %ld",(long)self.indexPath.row + 1,(long)_numberOfItems];
    }else{
        _pageControl.pageControll.text = [NSString stringWithFormat:@"%d / %ld",1,(long)_numberOfItems];
    }
}
#pragma mark --- UICollectionviewDelegate or dataSource
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.delegate xfbrowserPickerPhotoNum:self];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    XFBrowserPickerCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    
    if (!cell) {
        cell = [[XFBrowserPickerCell alloc]init];
    }
    
    if ([[_photoDataArray objectAtIndex:indexPath.row] isKindOfClass:[PHAsset class]]) {
        //加载相册中的数据时实用
        PHAsset *assetItem = [_photoDataArray objectAtIndex:indexPath.row];
        [cell loadPHAssetItemForPics:assetItem];
    }else if ([[_photoDataArray objectAtIndex:indexPath.row] isKindOfClass:[NSString class]]){
        //加载网络中的图片数据，图片地址使用
        
    }else if ([[_photoDataArray objectAtIndex:indexPath.row] isKindOfClass:[UIImage class]]){
        //加载 UIImage 类型的数据
        cell.pics.image = [_photoDataArray objectAtIndex:indexPath.row];
    }
    
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)index
{
    if (self.showAnimation == ShowAnimationOfPresent) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
    int itemIndex = (scrollView.contentOffset.x + self.picBrowse.frame.size.width * 0.5) / self.picBrowse.frame.size.width;
    if (!self.numberOfItems) return;
    int indexOnPageControl = itemIndex % self.numberOfItems;
    
    _pageControl.pageControll.text = [NSString stringWithFormat:@"%d / %ld",indexOnPageControl+1,(long)_numberOfItems];
    self.pageControl.currentPage = indexOnPageControl;
    
}

-(void)showIn:(UIViewController *)controller animation:(ShowAnimation)animation
{
    if (animation == ShowAnimationOfPush) {
        
        if (_isOpenAnimation == NO) {
            [controller.navigationController pushViewController:self animated:YES];
        }else{
            controller.navigationController.delegate = self;
            
            _animate = [XFBrowerAnimate new];
            _animate.style = PushAnimate;
            [controller.navigationController pushViewController:self animated:YES];
        }
        
    }else if (animation == ShowAnimationOfPresent){
        if (_isOpenAnimation == NO) {
            self.showAnimation = ShowAnimationOfPresent;
            [controller presentViewController:self animated:YES completion:nil];
        }else{
            self.showAnimation = ShowAnimationOfPresent;
            //设置动画效果
            self.transitioningDelegate = self;
            _animate = [XFBrowerAnimate new];
            _animate.style = PushAnimate;
            
            [controller presentViewController:self animated:YES completion:nil];
        }
    }
}

- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC
{
    return self.animate;
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source
{
    return self.animate;
}

-(id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed
{
    return self.animate;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
