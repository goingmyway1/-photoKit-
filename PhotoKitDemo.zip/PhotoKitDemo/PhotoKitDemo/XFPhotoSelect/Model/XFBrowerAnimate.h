//
//  XFBrowerAnimate.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Common.h"

typedef  NS_ENUM(NSInteger,AnimateStyle){
    PushAnimate,
    ZZBrowerAnimateStyleOfBoxCenter,
    ZZBrowerAnimateStyleOfBoxLeft,
};

@interface XFBrowerAnimate : NSObject<UIViewControllerAnimatedTransitioning>

@property(assign,nonatomic) AnimateStyle style;

@end
