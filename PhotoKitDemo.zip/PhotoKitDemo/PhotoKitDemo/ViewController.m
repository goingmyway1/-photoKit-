//
//  ViewController.m
//  PhotoKitDemo
//
//  Created by XF on 16/7/29.
//  Copyright © 2016年 xf. All rights reserved.
//

#import "ViewController.h"
#import "XFPhotoManager.h"
#import "Common.h"
#import "XFPicsCell.h"
#import "XFPhotoController.h"
@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (strong, nonatomic) UICollectionView *collectionView;

@property(strong,nonatomic) NSMutableArray *picArray;

@property (strong, nonatomic) UIButton *selectBtn;
@end

@implementation ViewController

-(NSMutableArray *)picArray{
    if (!_picArray) {
        _picArray = [NSMutableArray array];
    }
    return _picArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setUILayout];
}
-(void)setUILayout{
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    
    CGFloat photoSize = (self.view.frame.size.width - 50) / 3;
    flowLayout.minimumInteritemSpacing = 10.0;//item 之间的行的距离
    flowLayout.minimumLineSpacing = 10.0;//item 之间竖的距离
    flowLayout.itemSize = (CGSize){photoSize,photoSize};
    //        self.sectionInset = UIEdgeInsetsMake(0, 2, 0, 0);
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(10, 0, XF_VW - 20, photoSize * 3) collectionViewLayout:flowLayout];
    [_collectionView registerClass:[XFPicsCell class] forCellWithReuseIdentifier:@"PhotoCell"];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    _collectionView.backgroundColor = [UIColor whiteColor];
    [_collectionView setUserInteractionEnabled:YES];
    [self.view addSubview:_collectionView];
    _selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _selectBtn.frame = CGRectMake(80, _collectionView.frame.size.height + _collectionView.frame.origin.y + 40, 120, 40);
    [_selectBtn setTitle:@"选择图片" forState:UIControlStateNormal];
    [_selectBtn addTarget:self action:@selector(selectImage) forControlEvents:UIControlEventTouchUpInside];
    [_selectBtn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
    [self.view addSubview:_selectBtn];
}
-(void)selectImage{
    XFPhotoController *photoController  = [[XFPhotoController alloc]init];
    //选择图片的最大数
    photoController.selectPhotoOfMax = 8;
    //选择图片的回调
    [photoController showIn:self result:^(id responseObject) {
        NSArray *array = (NSArray *)responseObject;
        NSLog(@"%@",responseObject);
        [self.picArray addObjectsFromArray:array];
        [_collectionView reloadData];

    }];
}
#pragma mark - ****************  collectionViewDelegate
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.picArray.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    XFPicsCell *photoCell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoCell" forIndexPath:indexPath];
    if (!photoCell) {
        photoCell = [[XFPicsCell alloc]init];
    }
    photoCell.photo.image = [self.picArray objectAtIndex:indexPath.row];
    
    return photoCell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
