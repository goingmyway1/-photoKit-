//
//  XFPhotoListViewController.h
//  PhotoKitDemo
//
//  Created by XF on 16/7/30.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

@interface XFPhotoListViewController : UIViewController

@property (assign, nonatomic) NSInteger selectNum;

@property (strong, nonatomic) void (^photoResult)(id responseObject);;


@end
