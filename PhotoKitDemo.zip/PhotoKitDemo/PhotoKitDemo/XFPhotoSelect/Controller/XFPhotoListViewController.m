//
//  XFPhotoListViewController.m
//  PhotoKitDemo
//
//  Created by XF on 16/7/30.
//  Copyright © 2016年 xf. All rights reserved.
//

#import "XFPhotoListViewController.h"
#import "XFPhotoDatas.h"
#import "XFPhotoListCell.h"
#import <Photos/Photos.h>
#import "XFPhotoPickerViewController.h"

@interface XFPhotoListViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) UITableView *alumbTable;

@property (strong, nonatomic) PHPhotoLibrary *assetsLibrary;

@property (strong, nonatomic) NSMutableArray *alubms;

@property (strong, nonatomic) UIBarButtonItem *closeBtn;

@property (strong, nonatomic) XFPhotoDatas *datas;
@end

@implementation XFPhotoListViewController

-(UIBarButtonItem *)closeBtn{
    if (_closeBtn) {
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 44)];
        [button addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
        button.titleLabel.font = [UIFont systemFontOfSize:17.0f];
        [button.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17]];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTitle:@"关闭" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        
        _closeBtn = [[UIBarButtonItem alloc] initWithCustomView:button];

    }
    return _closeBtn;
}
-(void)close{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - **************** 懒加载获取图片数据类
-(XFPhotoDatas *)datas{
    if (!_datas) {
        _datas = [[XFPhotoDatas alloc]init];
    }
    return _datas;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem = _closeBtn;
    self.navigationItem.title = @"相册";
    
    _alumbTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, XF_VW, XF_VH) style:UITableViewStylePlain];
    _alumbTable.delegate = self;
    _alumbTable.dataSource = self;
    _alumbTable.separatorStyle = NO;
    [self.view addSubview:_alumbTable];
    
    _alubms = [NSMutableArray array];
    
    _alubms = [self.datas getPhotoListDatas];
}
#pragma mark - **************** UITableViewDelegate 
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _alubms.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    XFPhotoListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[XFPhotoListCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    }
    
    [cell loadPhotoListData:[_alubms objectAtIndex:indexPath.row]];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    XFPhotoPickerViewController *photopickerController = [[XFPhotoPickerViewController alloc]init];
    photopickerController.PhotoResult = self.photoResult;
    photopickerController.selectNum = self.selectNum;
    
    photopickerController.fetch = [self.datas getFetchResult:[_alubms objectAtIndex:indexPath.row]];
    photopickerController.isAlubSeclect = YES;
    
    [self.navigationController pushViewController:photopickerController animated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
