//
//  XFPhotoListCell.h
//  PhotoKitDemo
//
//  Created by XF on 16/7/30.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

@interface XFPhotoListCell : UITableViewCell


@property (strong, nonatomic) UIImageView *coverImage;/**< 相册图片，显示相册的最后一张图片 */

@property (strong, nonatomic) UILabel *title;/**< 相册标题，显示相册标题 */

@property (strong, nonatomic) UILabel *subTitle;/**< 相册副标题，显示相册中含有多少张图片 */
/**
 *  加载数据方法
 *
 *  @param assetItem 某个相册
 */
-(void)loadPhotoListData:(PHAssetCollection *)assetItem;
@end
