//
//  XFPicsCell.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFPicsCell : UICollectionViewCell

@property(strong,nonatomic) UIImageView *photo;

@end
