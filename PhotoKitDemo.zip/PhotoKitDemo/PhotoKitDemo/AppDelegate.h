//
//  AppDelegate.h
//  PhotoKitDemo
//
//  Created by XF on 16/7/29.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

