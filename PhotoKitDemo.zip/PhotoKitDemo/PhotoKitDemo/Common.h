//
//  Common.h
//  PhotoKitDemo
//
//  Created by XF on 16/7/30.
//  Copyright © 2016年 xf. All rights reserved.
//

#ifndef Common_h
#define Common_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Photos/Photos.h>
#import <AVFoundation/AVFoundation.h>

/**
 *  定义图片返回的类型枚举
 */
typedef NS_ENUM(NSInteger,XFImageType){
    XFImageTypeOfDefault,      //原图
    XFImageTypeOfThumb         //缩略图
};

/**
 *  控制器
 *
 *  @param self.view.frame.size.width 宽
 *
 *  @param self.view.frame.size.height 高
 */
#define XF_VW (self.view.frame.size.width)
#define XF_VH (self.view.frame.size.height)

#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)


/*
 颜色
 */
#define XF_RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define XF_RGB(r,g,b) XF_RGBA(r,g,b,1.0f)


/*
 图片
 */

//   相册列表页面右边箭头图片
#define PhotoListRightBtn      [UIImage imageNamed:@"XF_alumb_rightCell.png"]
//   相册列表页面，当没有数据时使用图片
#define NOPhoto_Data_Pic       [UIImage imageNamed:@"no_data.png"]
//   图片选中状态图片
#define Pic_Btn_Selected       [UIImage imageNamed:@"select_yes.png"]
//   图片未选中状态图片
#define Pic_btn_UnSelected     [UIImage imageNamed:@"select_no.png"]

#endif /* Common_h */
