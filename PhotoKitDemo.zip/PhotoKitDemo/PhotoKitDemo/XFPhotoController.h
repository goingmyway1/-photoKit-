//
//  XFPhotoController.h
//  PhotoKitDemo
//
//  Created by XF on 16/7/30.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Common.h"

/**
 *  设置Block
 */
typedef void(^XFPhotoResult)(id responseObject);
@interface XFPhotoController : NSObject

@property (assign, nonatomic) NSInteger selectPhotoOfMax;/**< 选择照片的最多张数 */

@property (assign, nonatomic) XFImageType imageType;/**< 设置图片的返回类型 */

/** 回调方法 */
-(void)showIn:(UIViewController *)controller result:(XFPhotoResult)result;
@end
