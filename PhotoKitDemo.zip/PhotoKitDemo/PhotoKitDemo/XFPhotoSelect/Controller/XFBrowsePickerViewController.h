//
//  XFBrowsePickerViewController.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"

typedef NS_ENUM(NSInteger, ShowAnimation){
    ShowAnimationOfPush,
    ShowAnimationOfPresent
    
};

@class XFBrowsePickerViewController;

@protocol XFBrowsePickerDelegate <NSObject>

@required

-(NSInteger)xfbrowserPickerPhotoNum:(XFBrowsePickerViewController *)controller;
-(NSArray *)xfbrowserPickerPhotoContent:(XFBrowsePickerViewController *)controller;
@optional
-(void)xfbrowerPickerPhotoRemove:(NSInteger)indexPath;
@end

@interface XFBrowsePickerViewController : UIViewController

@property (assign, nonatomic) id<XFBrowsePickerDelegate> delegate;

@property (assign, nonatomic) BOOL isOpenAnimation;/**< 是否开启动画效果 */

@property (assign, nonatomic) NSInteger showAnimation;

@property (strong, nonatomic) NSIndexPath *indexPath;/**< 滚动到指定位置(滚动到那张图片，通过下面属性) */

-(void)reloadData;

-(void)showIn:(UIViewController *)controller animation:(ShowAnimation)animation;
@end
