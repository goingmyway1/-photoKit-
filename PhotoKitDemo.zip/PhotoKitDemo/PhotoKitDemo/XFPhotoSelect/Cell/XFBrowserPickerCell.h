//
//  XFBrowserPickerCell.h
//  PhotoKitDemo
//
//  Created by XF on 16/8/2.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Common.h"
@interface XFBrowserPickerCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *pics;

-(void)loadPHAssetItemForPics:(PHAsset *)assetItem;

@end
